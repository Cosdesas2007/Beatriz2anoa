module Pronto
  class Error < StandardError; end
end
